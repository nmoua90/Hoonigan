package backend;

/**UndefinedItem
 * This class describes undefined objects that are read from JSON/XML files--extends from Item.
 * @author Hoonigan
 *
 */
public class UndefinedItem extends Item{
	/**UndefinedItem()
	 * Default Constructor.
	 */
	public UndefinedItem(){
	}
	
	
	 /**UndefinedItem(String name, String type, String id, int libraryID)
	 * Constructor that instantiates an UndefinedItem.
	 * @param name - name of Book
	 * @param type - type of item
	 * @param id - id of Book
	 * @param libraryID - the libraryID associated with this item
	 */
	public UndefinedItem(String name, String type, String id, int libraryID){
		this.item_name = name;
		this.item_type = type;
		this.item_id = id;
		this.libraryID = libraryID;
	}
	
	/**checkOut()
	 * Does nothing if called, only implemented due to inheritance constraints.
	 */
	public void checkOut(){}
	
	/**toString()
	 * Does nothing if called, only implemented due to inheritance constraints.
	 */
	@Override
	public String toString(){ return""; }
}
