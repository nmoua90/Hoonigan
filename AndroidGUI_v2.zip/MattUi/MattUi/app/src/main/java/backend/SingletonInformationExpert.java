package com.gui.hoonigan;


import com.implementation.hoonigan.*;
import java.util.Collection;
import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Multimap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

/**SingletonInformationExpert
 * This class implements the Singleton and Information Expert patterns. It contains meta-data fields which represent the entire database
 * of the program, as well as relevant methods that need to be called in multiple different classes. All fields and methods in this class
 * are global for the entire program.
 * @author Hoonigan
 *
 */
public class SingletonInformationExpert {
	//At first, there is no instance of this class
	private static SingletonInformationExpert instance = null;
			
	//HashMap with all Libraries
	private static Map<Integer, Library> libraryList = new HashMap<Integer, Library>();
	
	//HashMap with all User accounts [userName, password]
	private static Map<String, Client> clientList = new HashMap<String, Client>();
	
	//HashMap with only Admin accounts [userName, password]
	private static Map<String, Client> adminList = new HashMap<String, Client>();		
		
	//HashMap for allLibraryItems [ID, Item]
	private static Multimap<String, Item> libraryItemList = ArrayListMultimap.create();
	
	//HashMap containing Items that were misread from Load Files
	private static Multimap<String, Item> errorList = ArrayListMultimap.create();
	
	//User Storage Variables
	private static Client restoreUserAccount;
	
	private static Client currentUser;

	/**SingletonInformationExpert()
	 * Default constructor is disabled. No allowance to call the Constructor in Singleton Pattern.
	 */
	private void SingletonInformationExpert(){
	}
		
	/**getInstance()
	 * Implements the Singleton pattern, by only allowing one instance of this class.
	 * @return one, and only one instance of this class.
	 */
	public static SingletonInformationExpert getInstance(){
		if(instance==null){
			instance = new SingletonInformationExpert();
		}
		return instance;
	}

	/**instantiateDefaultAdmin()
	 * Create default Admin for system
	 */
	public static void instantiateDefaultAdmin(){
		Admin defaultAdmin = new Admin("admin", "admin", "admin", "admin".toCharArray(), "admin", "admin", "admin");
		clientList.put(defaultAdmin.getUserName(), defaultAdmin);
		adminList.put(defaultAdmin.getUserName(), defaultAdmin);
	}
	
	/**getLibraryItemList()
	 * Simple getter.
	 * @return a Multimap with all Items in the database. 
	 */
	public static Multimap<String, Item> getLibraryItemList() {
		return libraryItemList;
	}

	/**setLibraryItemList(Multimap<String, Item> libraryItemList)
	 * Simple setter.
	 * @param libraryItemList - The Multimap containing all Items in the database.
	 */
	public static void setLibraryItemList(Multimap<String, Item> libraryItemList) {
		SingletonInformationExpert.libraryItemList = libraryItemList;
	}

	/**setInstance(SingletonInformationExpert instance)
	 * Typical setter.
	 * @param instance - the one, and only one, instance of this class.
	 */
	public static void setInstance(SingletonInformationExpert instance) {
		SingletonInformationExpert.instance = instance;
	}
			
	/**addToItemsHashMap(Item libItem)
	 * Adds an Item to the MultiMap that stores all Item Objects.
	 * @param libItem
	 */
	public static void addToItemsHashMap(Item libItem){
		libraryItemList.put(libItem.getItem_id(), libItem);
	}
	
	/**addToErrorMap(Item libItem)
	 * Adds an Item to the MultiMap, containing Items types that are not recognized.
	 * @param libItem - the Item to be added to the MultiMap, containing Item types that are not recognized.
	 */
	public static void addToErrorMap(Item libItem){
		errorList.put(libItem.getItem_id(), libItem);
	}
	
	/**addToClientHashMap(Client client)
	 * Adds a Client to the Map that stores all Client Objects.
	 * @param client
	 */
	public static void addToClientHashMap(Client client){
		clientList.put(client.getUserName(), client);
	}
	
	/**addToLibraryHashMap(Library library)
	 * Adds a Library to the Map that stores all Library Objects.
	 * @param library - the Library to be added
	 */
	public static void addToLibraryHashMap(Library library){
		libraryList.put(library.getLibraryID(), library);
	}

	/**getLibraryList()
	 * Typical getter.
	 * @return - the Map that contains all Library Objects stored in this database.
	 */
	public static Map<Integer, Library> getLibraryList() {
		return libraryList;
	}

	/**setLibraryList(Map<Integer, Library> libraryList)
	 * Typical setter.
	 * @param libraryList - a Map that contains all Library Objects stored in this database.
	 */
	public static void setLibraryList(Map<Integer, Library> libraryList) {
		SingletonInformationExpert.libraryList = libraryList;
	}

	/**getClientList()
	 * Typical getter.
	 * @return - a Map, containing all Clients in the database.
	 */
	public static Map<String, Client> getClientList() {
		return clientList;
	}

	/**setClientList(Map<String, Client> clientList)
	 * Typical setter.
	 * @param clientList - a Map, containing all Clients in the database.
	 */
	public static void setClientList(Map<String, Client> clientList) {
		SingletonInformationExpert.clientList = clientList;
	}
	
	/**getClientAccount(String userName)
	 * This method checks if a username is valid, and returns the Client if it is valid, and null otherwise.
	 * @param userName - the username of the client.
	 * @return the client's account if it exists, null otherwise.
	 */
	public Client getClientAccount(String userName){
		if(clientList.containsKey(userName)){
			return clientList.get(userName);
		}
		return null;
	}
	
	/**checkPassword(String username, char[] enteredPassword)
	 * Checks two passwords, to see if they match.
	 * @param username - the current User
	 * @param enteredPassword - the entered password for the current user
	 * @return true or false, based on whether the two passwords match.
	 */
	public boolean checkPassword(String username, char[] enteredPassword){
		if(userExists(username)){
			String enteredPW = new String(enteredPassword);
			String savedPW = new String(clientList.get(username).getPassword());
			
			if(enteredPW.compareTo(savedPW) == 0){
				return true;
			}
		}
		
		return false;
	}
	
	/**isAdmin(String userName)
	 * This method checks to see if a username is an Admin with the system.
	 * @param userName - the userName to be queried  
	 * @return true or false, based on the status of the current user being an admin.
	 */
	public boolean isAdmin(String userName){
		if(adminList.containsKey(userName)){
			return true;
		}
		return false;
	}
	
	/**getRestoreUserAccount()
	 * Used when current User needs to restore an account. Returns a Client object that matches the current user's metadata.
	 * @return the current Client, who wants to restore their account.
	 */
	public static Client getRestoreUserAccount() {
		return restoreUserAccount;
	}

	/**setRestoreUserAccount(Client restoreUserAccount)
	 * Used when current User needs to restore an account. Sets a Client account to be restored, for the current User.
	 * @param restoreUserAccount - set the current Client object that needs to be restored, for the current user
	 */
	public static void setRestoreUserAccount(Client restoreUserAccount) {
		SingletonInformationExpert.restoreUserAccount = restoreUserAccount;
	}

	/**userExists(String userName)
	 * Checks if username is already in the system.
	 * @param userName - the userName of the current user
	 * @return true or false, based on whether the username exists in the system.
	 */
	public boolean userExists(String userName){
		if(clientList.containsKey(userName)){
			return true;
		}
		return false;
	}

	/**searchForUser(String lastName)
	 * Search for a user account based on Last Name
	 * @param lastName - the user's Last Name
	 * @return - a list with users, who share the same Last Name as the parameter field
	 */
	public List<Client> searchForUser(String lastName){
		List<Client> foundMembers = new ArrayList<Client>();
		
	    for(Entry<String, Client> entry: clientList.entrySet()) {
	    	if(entry.getValue().getLastName().compareToIgnoreCase(lastName) == 0){
		        foundMembers.add(entry.getValue());
	    	}
	    }
		return foundMembers;
	}
	
	/**searchByAddress(String address, List<Client> myList)
	 * Search for a user account based on an address.
	 * @param address - the queried user's address
	 * @param myList - a pre-queried List that has been filtered to include only user's with the same Last Name as the current queried user.
	 * @return - the current user's Account information if found, NULL if otherwise.
	 */
	public Client searchByAddress(String address, List<Client> myList){
		Client current;
		
		for(int i = 0; i<myList.size(); i++){
			current = myList.get(i);
			if(current.getStreetAddress().compareToIgnoreCase(address) == 0){
				return current;
			}
		}
		
		return null;
	}
	
	
	/**searchForItem(String searchId)
	 * This method searches a HashMap using a search field, and returns a List of matching Items found
	 * @param searchByWhatField - If 0, search by ID. If 1, search by Title. If 2, search by Item Type.
	 * @param searchId - The querying Item's ID, which is used to search for the individual Item.
	 * @return foundItems, a List of Item objects found. If no matches, empty list is returned.
	 */
	public List<Item> searchForItem(int searchByWhatField, String searchId){
		//Create Iterator with Key values
		Iterator<String> mySearchingItr = libraryItemList.keySet().iterator();
		
		//Create ArrayList to store matching search elements
		List<Item> foundItems = new ArrayList<Item>();
		
		//Determine what you are searching for
		//If you are searching by ID
		if(searchByWhatField == 0){
			for(Item item : libraryItemList.values()) {
				//check to see if you found the searchId, by checking if current items.getItemID == searchId
				if(item.getItem_id().compareToIgnoreCase(searchId) == 0)
					foundItems.add(item);
			}
		}
		//If you are searching by Title
		else if(searchByWhatField == 1){
			for(Item item : libraryItemList.values()) {
				//check to see if you found the searchId, by checking if current items.getItemID == searchId
				if(item.getItem_name().compareToIgnoreCase(searchId) == 0)
					foundItems.add(item);
			}
		}
		//If you are searching by Item Type
		else if(searchByWhatField == 2){
			for(Item item : libraryItemList.values()) {
				//check to see if you found the searchId, by checking if current items.getItemID == searchId
				if(item.getItem_type().compareToIgnoreCase(searchId) == 0)
					foundItems.add(item);
			}
		//You want all the items of the library
		}else{
			for(Item item : libraryItemList.values()) {
					foundItems.add(item);
			}
		}
		
		//Return the found library_item [or null if nothing found]
		return foundItems;
	}

	
	 /**filterByType(String itemType, List<Item> myList)
	  * Takes in a List of Items, and filters the List containing Items by the Item Type
	 * @param itemType - the Type to be filtered by
	 * @param myList - the List to be filtered
	 * @return - a List of filtered Items
	 */
	public List<Item> filterByType(String itemType, List<Item> myList){
		List<Item> filteredResults = new ArrayList<Item>();
		
		if(itemType.compareToIgnoreCase("BOOK") == 0){
			for(Item item : myList){
				if(item.getItem_type().compareTo("BOOK") == 0)
					filteredResults.add(item);
			}
		}
		else if(itemType.compareToIgnoreCase("MAGAZINE") == 0){
			for(Item item : myList){
				if(item.getItem_type().compareTo("MAGAZINE") == 0)
					filteredResults.add(item);
			}
		}
		else if(itemType.compareToIgnoreCase("CD") == 0){
			for(Item item : myList){
				if(item.getItem_type().compareTo("CD") == 0)
					filteredResults.add(item);
			}
		}	
		else if(itemType.compareToIgnoreCase("DVD") == 0){
			for(Item item : myList){
				if(item.getItem_type().compareTo("DVD") == 0)
					filteredResults.add(item);
			}
		}
		
		return filteredResults;
	}
	
	/**getAdminList()
	 * Typical getter.
	 * @return - a Map, containing all Admins within the system.
	 */
	public static Map<String, Client> getAdminList() {
		return adminList;
	}

	/**setAdminList(Map<String, Client> adminList)
	 * Typical setter.
	 * @param adminList - a Map, containing all Admins within the system.
	 */
	public static void setAdminList(Map<String, Client> adminList) {
		SingletonInformationExpert.adminList = adminList;
	}

	/**Client getCurrentUser()
	 * Typical getter.
	 * @return - the current Client in the thread.
	 */
	public static Client getCurrentUser() {
		return currentUser;
	}

	/**setCurrentUser(Client currentUser)
	 * Typical setter.
	 * @param currentUser - the current Client in the thread.
	 */
	public static void setCurrentUser(Client currentUser) {
		SingletonInformationExpert.currentUser = currentUser;
	}

	/**getErrorList()
	 * Typical getter.
	 * @return - a MultiMap, containing all unrecognized Items in the system.
	 */
	public static Multimap<String, Item> getErrorList() {
		return errorList;
	}

	/**setErrorList(Multimap<String, Item> errorList)
	 * Typical setter.
	 * @param errorList - a MultiMap, containing all unrecognized Items in the system.
	 */
	public static void setErrorList(Multimap<String, Item> errorList) {
		SingletonInformationExpert.errorList = errorList;
	}
		
}