package backend;

/**Admin class
 * Simple class, derived from Client.
 * @author Hoonigan
 */
public class Admin extends Client{
	protected final boolean access = true;
	
	/**Admin(String firstName, String lastName, String userName, char[] password, 
			String streetAddress, String securityQuestion, String securityAnswer)
	 * Simple Constructor.
	 * @param firstName - first Name of Admin
	 * @param lastName - last Name of Admin
	 * @param userName - userName of Admin
	 * @param password - password of Admin
	 * @param streetAddress - address of Admin
	 * @param securityQuestion - security question of Admin
	 * @param securityAnswer - security answer of Admin
	 */
	public Admin(String firstName, String lastName, String userName, char[] password, 
			String streetAddress, String securityQuestion, String securityAnswer){
		this.firstName = firstName;
		this.lastName = lastName;
		this.userName = userName;
		this.password = password;
		this.streetAddress = streetAddress;
		this.securityAnswer = securityAnswer;
		this.securityQuestion = securityQuestion;
	}

	/**getAccess()
	 * This method returns the access level of an Admin
	 * @return the access level of an Admin
	 */
	public boolean getAccess() {
		return access;
	}
		
}