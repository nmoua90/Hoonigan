package com.example.android.ics372androidproject;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class ItemInfo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_info);
    }

    public void goToUserPage(View view){
        //fill in logic to change views to MemberPage. Try and re-use same method from Catalog.
    }
}
