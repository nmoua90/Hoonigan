package com.example.android.ics372androidproject;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MemberPage extends AppCompatActivity {
    Button renewButton;
    Button returnButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_member);


    }

    public void renewItem(View view) {
        //Fill in logic to renew an item
    }

    public void returnItem(View view){
        /*Fill in logic to return an item or multiple items.

          Could also have this method call an updateCheckedOutItems()
          method to display the current list of items after a return
          has taken place.
         */
    }

    public void goToLibraryCatalog(View view){
        //Fill in logic to switch views to CheckoutCatalog view on buttonclick
    }

    public void logout(View view){
        //Fill in logic to log out current user and return to home page.
    }
}