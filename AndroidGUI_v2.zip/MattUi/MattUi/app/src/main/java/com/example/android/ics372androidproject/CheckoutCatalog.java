package com.example.android.ics372androidproject;

import android.graphics.Typeface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

public class CheckoutCatalog extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_catalog);

        //Tried to load in a custom font. Failed.
        TextView tx = (TextView)findViewById(R.id.libraryName);
        Typeface custom_font = Typeface.createFromAsset(getAssets(),  "fonts/Lobster-Regular.ttf");
        tx.setTypeface(custom_font);

    }

    public void spinnerArrayOptions(){
        Spinner spinner = (Spinner) findViewById(R.id.itemsAvailable);
        // Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.library_array, android.R.layout.simple_spinner_item);
        // Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // Apply the adapter to the spinner
        spinner.setAdapter(adapter);
    }

    public void getItemInfo(View view){
        //Fill in logic to change views to the view containing more detailed item info
        //based on what spinner item the user clicked on.
    }

    public void goToUserPage(View view){
        //Add logic to change to MemberPage view
    }
}
