/**
 * Package contains example of XML Parser, seperated by classes.
 */
/**
 * @author Nhia
 *
 */
package example;