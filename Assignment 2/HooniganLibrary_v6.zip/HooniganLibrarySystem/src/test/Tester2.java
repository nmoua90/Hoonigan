package test;

import com.implementation.*;
import com.gui.hoonigan.*;

/**
 * Trying to understand how this program works...
 * 
 *
 */
public class Tester2 {
	public static void main(String[] args){
		
	}
}
