package Tests;

import com.gui.hoonigan.*;
import com.implementation.hoonigan.*;

import java.lang.reflect.Type;

import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;

import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Multimap;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * 
 * @author Hoonigan
 *
 */
public class LibrarySerializer {
	//This instantiates all relevant lists for metadata
	private SingletonInformationExpert globalVariables = SingletonInformationExpert.getInstance();
	
	//HashMap with all Libraries
	private static Multimap<Integer, Library> multiLibraryList = ArrayListMultimap.create();
	private Map<Integer, Library> libraryList = globalVariables.getLibraryList();
		
	//HashMap with all User accounts [userName, password]
	private static Multimap<String, Client> multiClientList = ArrayListMultimap.create();
	private Map<String, Client> clientList = globalVariables.getClientList();
			
	//HashMap for all LibraryItems in system [ID, Item]
	private Multimap<String, Item> libraryItemList = globalVariables.getLibraryItemList();
		
	/**
	 * Default
	 */
	public LibrarySerializer(){}

	/**
	 * This class defines different types of Objects to serialize
	 * @author Hoonigan
	 *
	 */
    public static class ItemSerializer  {
        public JsonElement serialize(final Object saveThis, final Type type, final JsonSerializationContext context) {
        	//Create a new Json object
            JsonObject result = new JsonObject();
            
            //If the passed in Object is an item, set the value to be saved to an Item
            if(saveThis instanceof Item){
            	Item item = (Item) saveThis;
            
            	//Add Item fields to the Json object [if it is a DVD/BookItem/CD/Magazine/
	            result.add("item_name", new JsonPrimitive(item.getItem_name()));
	            result.add("item_type", new JsonPrimitive(item.getItem_type()));
	            result.add("item_id", new JsonPrimitive(item.getItem_id()));
	            result.add("library_id", new JsonPrimitive(item.getLibraryID()));
	            result.add("checkedOut", new JsonPrimitive(item.isCheckedOut()));
	            result.add("returnDate", new JsonPrimitive(item.returnDate()));
	            result.add("checkedOutBy", new JsonPrimitive(item.getCheckedOutBy()));
	            
	            //Add Item specific fields
	            //If a book, add item_author when writing out
	            if (item instanceof BookItem) {
	            	result.add("item_author", new JsonPrimitive(((BookItem) item).getItem_author()));
	            }
	            //If a CD, add artist when writing
	            else if (item instanceof CD) {
	            	result.add("item_artist", new JsonPrimitive(((CD) item).getItem_artist()));
	            }
	            //If a Magazine, add volume when writing
	            else if (item instanceof Magazine) {
	            	result.add("item_volume", new JsonPrimitive(((Magazine) item).getVolume()));
	            }
	            
	        //If object is a client    
	        }else if(saveThis instanceof Client){
	        	Client client = (Client) saveThis;
	            String pw = new String(client.getPassword());
	            
            	//Add Item fields to the Json object [if it is a DVD/BookItem/CD/Magazine/
	            result.add("clientUserName", new JsonPrimitive(client.getUserName()));
	            result.add("clientPW", new JsonPrimitive(pw));
	            result.add("clientFirstName", new JsonPrimitive(client.getFirstName()));
	            result.add("clientLastName", new JsonPrimitive(client.getLastName()));
	            result.add("clientSecAns", new JsonPrimitive(client.getSecurityAnswer()));
	            result.add("clientSecQues", new JsonPrimitive(client.getSecurityQuestion()));
	            result.add("clientAddress", new JsonPrimitive(client.getStreetAddress()));
	            result.add("clientAccess", new JsonPrimitive(client.getAccess()));
	            //result.add("clientName", new JsonPrimitive(client.getItemsCheckedOut()));
	            
	            
	            //Add Item specific fields
	            if (client instanceof Admin) {
	            	result.add("access", new JsonPrimitive(((Admin) client).getAccess()));
	            }else if (client instanceof Member) {
	            	result.add("access", new JsonPrimitive(((Member) client).getAccess()));
	            }
	        }
            
            //If object is a Library
	        else{
	        	Library library = (Library) saveThis;
	        	
	            result.add("libraryID", new JsonPrimitive(String.valueOf(library.getLibraryID())));
	            //result.add("", new JsonPrimitive(library.getLibraryCatalogMap()));
	        }
            
            //Return a Json object
            return result;
        }
    }
    
    /**
     * Takes in a Multi-Map of Items and saves everything
     * @param libraryMap
     */
    public static void SerializeLibraryCatalog(Multimap<String, Item> libraryMap) {

		System.out.println("I'm in SerializeLibraryCatalog()");
    	//Create an array that holds Strings
        ArrayList<String> items = new ArrayList<String>();

        //Create a GSON Builder, which will use info from Item
        com.google.gson.Gson gson = new GsonBuilder().registerTypeAdapter(Item.class, new ItemSerializer()).create();
        
        System.out.println("I made it past the Gson assignment");
        //For all the Items from the passed in Multi-Map
		for (Item item : libraryMap.values()){
			//Set a string to equal the JSON object of an Item
			String jo = gson.toJson(item);
			//Add this String to your ArrayList
			items.add(jo);
		}
		
		//Create a StringBuilder, which will store all Items with the JSON file into an array called library_items
		StringBuilder sb = new StringBuilder("{\n  \"library_items\":\n  [\n");
		
		//For everything in your ArrayList
		for (int i = 0; i < items.size() - 1; i++){
			sb.append("    {\n");
			
			//Get the i'th element
			String string = "      " + items.get(i);
			sb.append(string);
			
			sb.append(",\n");
			
		}
		
		//Your String builder is complete, close the syntax of the JSON array
		sb.append(items.get(items.size() - 1) + "\n    }\n  ]\n}");
		
		
		//Attempt to serialize to JSON
		try {
			//Name your save file
			File file = new File("LibrarySave.json");
			
			//If the file does not exist, create it
			if (!file.exists()){
				file.createNewFile();
			}
			
			//Get a Printstream ready to write to your previously declared file 
			PrintStream out = new PrintStream(new FileOutputStream("LibrarySave.json"));
			
			//Print all elements you put in the Stringbuilder, close when done
			out.print(sb);
			out.close();			
		} catch (Exception ex) {
			System.out.println("Error writing file");
		}
    }
    
    /**
     * Takes in a Multi-Map and saves everything
     * @param libraryMap
     */
    public static void SerializeClientDatabase(Map<String, Client> clientMap) {
    	convertIntoClientMultiMap(clientMap);
    	
    	//Create an array that holds Strings
        ArrayList<String> clients = new ArrayList<String>();

		System.out.println("hi");
        //Create a GSON Builder, which will use info from Item
        com.google.gson.Gson gson = new GsonBuilder().registerTypeAdapter(Client.class, new ItemSerializer()).create();
        
        //For all the Items from the passed in Multi-Map
		for (Client client : clientMap.values()){
			//Set a string to equal the JSON object of an Item
			String user = gson.toJson(client);
			//Add this String to your ArrayList
			clients.add(user);
		}
		
		//Create a StringBuilder, which will store all Items with the JSON file into an array called library_items
		StringBuilder sb = new StringBuilder("{\n  \"client_list\":\n  [\n");
		
		//For everything in your ArrayList
		for (int i = 0; i < clients.size() - 1; i++){
			sb.append("    {\n");
			
			//Get the i'th element
			String string = "      " + clients.get(i);
			sb.append(string);
			
			sb.append(",\n");
			
		}
		
		//Your String builder is complete, close the syntax of the JSON array
		sb.append(clients.get(clients.size() - 1) + "\n    }\n  ]\n}");
		
		//Attempt to serialize to JSON
		try {
			//Name your save file
			File file = new File("ClientsSave.json");
			
			//If the file does not exist, create it
			if (!file.exists()){
				file.createNewFile();
			}
			
			//Get a Printstream ready to write to your previously declared file 
			PrintStream out = new PrintStream(new FileOutputStream("ClientsSave.json"));
			
			//Print all elements you put in the Stringbuilder, close when done
			out.print(sb);
			out.close();			
		} catch (Exception ex) {
			System.out.println("Error writing file");
		}
    }
    
    /**
     * 
     */
    public static void convertIntoLibraryMultiMap(Map<Integer, Library> map){
    	for (int key : map.keySet()){
    		multiLibraryList.put(key, map.get(key));
    	}
    }
    
    /**
     * 
     */
    public static void convertIntoClientMultiMap(Map<String, Client> map){
    	for (String key : map.keySet()){
    		multiClientList.put(key, map.get(key));
    	}
    }
    
    
    /**
     * 
     * @param option - 0 for items, 1 for members, 2 for libraries
     */
    public static void serializeMapOfObjects(int objectToSerialize){
    	//Serialize Items
    	if(objectToSerialize==0){

    		System.out.println("I'm in serializeMapOfObjects()");
    		//You have two items
            DVD dvd = new DVD("Shut Up, Little Man",  "DVD", "shutu01", 0, 1);
            Magazine mag = new Magazine("LAMB",  "Magazine", "fatem01", "Volume 1", 0, 1);

            //Get a Map of all Items
            Multimap<String, Item> libraryMap = ArrayListMultimap.create();

            libraryMap.put(dvd.getItem_id(), dvd);
            libraryMap.put(mag.getItem_id(), mag);


    		System.out.println("I'm heading to SerializeLibraryCatalog()");
            SerializeLibraryCatalog(libraryMap);
    	}
    	//objectToSerialize is Client
    	else if(objectToSerialize==1){
    		
                //Replace with actual Map in final
            	Map<String, Client> memberMap = new HashMap<String, Client>();
            	
            	//You have two clients
            	char[] password = {'a','w'};
                Member joe = new Member("joe", "smith", "jsmith8", password, "911 fake st", "are you fun", "yes");
                Admin admin = new Admin("admin", "admin", "admin", password, "admin", "admin", "admin");
                
                //Put them in a Map
                memberMap.put(joe.getUserName(), joe);
                memberMap.put(admin.getUserName(), admin);
               
                //Save the Map to a file
                SerializeClientDatabase(memberMap);
                
    	}
    	else{
    		
    	}
    	
    }
    
    public static void main(final String[] args) {
        	//You have two items
            DVD dvd = new DVD("Shut Up, Little Man",  "DVD", "shutu01", 0, 1);
            Magazine mag = new Magazine("FATE",  "Magazine", "fatem01", "Volume 1", 0, 1);
            
            //Get a Map of all Items
                Multimap<String, Item> libraryMap = ArrayListMultimap.create();
                
            
                libraryMap.put(dvd.getItem_id(), dvd);
                libraryMap.put(mag.getItem_id(), mag);
                
                //Save this Multi-Map to a file
                OriginalSerialize.SerializeLibraryCatalog(libraryMap);
              
              //You have two clients
            	char[] password = {'a','w'};
                Member joe = new Member("joe", "smith", "jsmith8", password, "911 fake st", "are you fun", "yes");
                Admin admin = new Admin("admin", "admin", "admin", password, "admin", "admin", "admin");
                
                
                //Replace with actual Map in final
            	Map<String, Client> memberMap = new HashMap<String, Client>();
            	
            	
                //Put them in a Map
                memberMap.put(joe.getUserName(), joe);
                memberMap.put(admin.getUserName(), admin);
               
                //Save the Map to a file
                SerializeClientDatabase(memberMap);
    
        
    	//Serialize Items
        LibrarySerializer.serializeMapOfObjects(0);
        

    	//Serialize 
    	LibrarySerializer.serializeMapOfObjects(1);
    }


}