package com.implementation.hoonigan;

import com.google.gson.JsonPrimitive;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**GsonRules class
 * 
 * This class defines the GSON Parsing Rules, which will determine how the GSON Parser parses the JSON file
 * @author Hoonigan
 * 
 */
public class GsonItem{
	/**Invariant Comments
	 * - itemName is a String that will be parsed based on the Parser recognizing the SerializedName "item_name".
	 * - itemType is a String that will be parsed based on the Parser recognizing the SerializedName "item_type".
	 * - itemId is a String that will be parsed based on the Parser recognizing the SerializedName "item_id".
	 * - itemArtist is a String that will be parsed based on the Parser recognizing the SerializedName "item_artist".
	 * - itemAuthor is a String that will be parsed based on the Parser recognizing the SerializedName "item_author".
	 * - itemVolume is a string that will be parsed based on the Parser recognizing the SerializedName "item_volume".
	 */ 
	@SerializedName("item_volume")
	@Expose
	private String itemVolume;
	
	@SerializedName("item_name")
	@Expose
	private String itemName;
	
	@SerializedName("item_type")
	@Expose
	private String itemType;
	
	@SerializedName("item_id")
	@Expose
	private String itemId;
	
	@SerializedName("item_artist")
	@Expose
	private String itemArtist;
	
	@SerializedName("item_author")
	@Expose
	private String itemAuthor;

	@SerializedName("library_id")
	@Expose
	private String libID;
	
	@SerializedName("checkedOut")
	@Expose
	private String checkedOut;
	
	@SerializedName("checkedOutBy")
	@Expose
	private String checkedOutBy;
	
	@SerializedName("returnDate")
	@Expose
	private String returnDate;
	
	
    
	public String getLibID() {
		return libID;
	}

	public void setLibID(String libID) {
		this.libID = libID;
	}

	public String getCheckedOut() {
		return checkedOut;
	}

	public void setCheckedOut(String checkedOut) {
		this.checkedOut = checkedOut;
	}

	public String getCheckedOutBy() {
		return checkedOutBy;
	}

	public void setCheckedOutBy(String checkedOutBy) {
		this.checkedOutBy = checkedOutBy;
	}

	public String getReturnDate() {
		return returnDate;
	}

	public void setReturnDate(String returnDate) {
		this.returnDate = returnDate;
	}

	/**getItemVolume()
	 * Simple getter method
	 * @return the item volume
	 */
	public String getItemVolume() {
		return itemVolume;
	}

	/**setItemVolume()
	 * Simple setter method
	 * @param itemName - the item volume to be changed
	 */
	public void setItemVolume(String itemVolume) {
		this.itemVolume = itemVolume;
	}
	
	/**getItemName()
	 * Simple getter method
	 * @return the item name
	 */
	public String getItemName() {
		return itemName;
	}

	/**setItemName()
	 * Simple setter method
	 * @param itemName - the item name to be changed
	 */
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	/**getItemType()
	 * Simple getter method
	 * @return the item type
	 */
	public String getItemType() {
		return itemType;
	}

	/**setItemType()
	 * Simple setter method
	 * @param itemType - the item type to be changed
	 */
	public void setItemType(String itemType) {
		this.itemType = itemType;
	}

	/**getItemId()
	 * Simple getter method
	 * @return the item id
	 */
	public String getItemId() {
		return itemId;
	}

	/**setItemId()
	 * Simple setter method
	 * @param itemId - the item id to be changed
	 */
	public void setItemId(String itemId) {
		this.itemId = itemId;
	}

	/**getItemArtist()
	 * Simple getter method
	 * @return the item artist
	 */
	public String getItemArtist() {
		return itemArtist;
	}

	/**setItemArtist()
	 * Simple setter method
	 * @param itemArtist - the item artist to be changed
	 */
	public void setItemArtist(String itemArtist) {
		this.itemArtist = itemArtist;
	}

	/**getItemAuthor()
	 * Simple getter method
	 * @return the item author
	 */
	public String getItemAuthor() {
		return itemAuthor;
	}

	/**setItemAuthor()
	 * Simple setter method
	 * @param itemAuthor - the item author to be changed
	 */
	public void setItemAuthor(String itemAuthor) {
		this.itemAuthor = itemAuthor;
	}

}