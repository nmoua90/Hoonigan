package com.implementation.hoonigan;

import java.util.ArrayList;
import java.util.List;

/**Client class
 * Abstract class, is the base foundation for Users within the Hoonigan System.
 * @author Hoonigan
 *
 */
public abstract class Client {
	protected String firstName;
	protected String lastName;
	protected String userName;
	protected char[] password;
	protected String streetAddress;
	protected String securityQuestion;
	protected String securityAnswer;
	protected List<Item> itemsCheckedOut = new ArrayList<Item>();
	
	/**Client()
	 * Default constructor
	 */
	public Client(){
	}

	/**getFirstName()
	 * Typical getter.
	 */
	public String getFirstName() {
		return firstName;
	}

	/**setFirstName(String firstName)
	 * Typical setter.
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**getLastName()
	 * Typical getter.
	 */
	public String getLastName() {
		return lastName;
	}

	/**setLastName(String lastName)
	 * Typical setter.
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**getUserName()
	 * Typical getter.
	 */
	public String getUserName() {
		return userName;
	}

	/**setUserName(String userName)
	 * Typical setter.
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}

	/**getPassword()
	 * Typical getter.
	 */
	public char[] getPassword() {
		return password;
	}

	/**setPassword(char[] password)
	 * Typical setter.
	 */
	public void setPassword(char[] password) {
		this.password = password;
	}

	/**getStreetAddress()
	 * Typical getter.
	 */
	public String getStreetAddress() {
		return streetAddress;
	}

	/**setStreetAddress(String streetAddress)
	 * Typical setter.
	 */
	public void setStreetAddress(String streetAddress) {
		this.streetAddress = streetAddress;
	}

	/**getSecurityQuestion()
	 * Typical getter.
	 */
	public String getSecurityQuestion() {
		return securityQuestion;
	}

	/**setSecurityQuestion(String securityQuestion)
	 * Typical setter.
	 */
	public void setSecurityQuestion(String securityQuestion) {
		this.securityQuestion = securityQuestion;
	}

	/**getSecurityAnswer()
	 * Typical getter.
	 */
	public String getSecurityAnswer() {
		return securityAnswer;
	}

	
	/**getItemsCheckedOut()
	 * Typical getter.
	 */
	public List<Item> getItemsCheckedOut() {
		return itemsCheckedOut;
	}

	/**setItemsCheckedOut(List<Item> itemsCheckedOut)
	 * Typical setter.
	 */
	public void setItemsCheckedOut(List<Item> itemsCheckedOut) {
		this.itemsCheckedOut = itemsCheckedOut;
	}
	
	/**addToCheckedOutList(Item item)
	 * Adds an Item to the current Client's List of checked out Items.
	 * @param item - the Item to be added to the current user
	 */
	public void addToCheckedOutList(Item item){
		this.itemsCheckedOut.add(item);
	}

	
	/**removeFromCheckedOutList(Item item)
	 * Removes an Item from the current Client's List of checked out Items.
	 * @param item - the item being checked in
	 * @return 0 if user failed to check an item in, else return 1 if user suceeded in checking an item in
	 */
	public int removeFromCheckedOutList(Item item){
		for(int i = 0; i<itemsCheckedOut.size(); i++){
			if(itemsCheckedOut.get(i).equals(item)){
				if(itemsCheckedOut.get(i).getUniqueQuantityID() == item.getUniqueQuantityID()){
					itemsCheckedOut.remove(i);
					return 1;
				}
			}
		}
		return 0;
	}
	
	/**getAccess()
	 * This method returns the access level of a Client
	 * @return the access level of a Client
	 */
	public abstract boolean getAccess();
		
}
