package com.implementation.hoonigan;

import java.time.LocalDate;

/**Magazine class
 * 
 * A simple Magazine class--extended from Abstract Library_Items class
 * @author Hoonigan
 *
 */

public class Magazine extends Item{
	private String volume;
	
	/**Magazine()
	 * Default Constructor
	 */
	public Magazine(){
	}
	
	/**Magazine(String name, String type, String id)
	 * Constructor which instantiates a Magazine object with no volume
	 * and default status
	 * @param name - name of Magazine
	 * @param type - type of item
	 * @param id - id of Magazine
	 */
	public Magazine(String name, String type, String id, 
			int libraryCode, 
			int uniqueQuantityID){
		libraryID = libraryCode;
		this.volume = "";
		item_name = name;
		item_type = type;
		item_id = id;
		checkedOut = false;
		returnDate = "NONE";
		this.uniqueQuantityID = uniqueQuantityID;
		this.status = "AVAILABLE";
		this.checkoutable = true;
	}
	
	/**Magazine(String name, String type, String id)
	 * Constructor which instantiates a Magazine object with given volume
	 * and default status
	 * @param name - name of Magazine
	 * @param type - type of item
	 * @param id - id of Magazine
	 * @param volume - volume of Magazine
	 */
	public Magazine(String name, String type, String id, String volume, 
			int libraryCode, 
			int uniqueQuantityID){
		libraryID = libraryCode;
		this.volume = volume;
		item_name = name;
		item_type = type;
		item_id = id;
		checkedOut = false;
		returnDate = "NONE";
		this.uniqueQuantityID = uniqueQuantityID;
		this.status = "AVAILABLE";
		this.checkoutable = true;
	}
	
	/**Magazine(String name, String type, String id)
	 * Constructor which instantiates a Magazine object with no volume
	 * and given status
	 * @param name - name of Magazine
	 * @param type - type of item
	 * @param id - id of Magazine
	 */
	public Magazine(String name, String type, String id, 
			int libraryCode, 
			int uniqueQuantityID,
			String status,
			boolean checkoutable){

		super(status, checkoutable);
		libraryID = libraryCode;
		this.volume = "";
		item_name = name;
		item_type = type;
		item_id = id;
		checkedOut = false;
		returnDate = "NONE";
		this.uniqueQuantityID = uniqueQuantityID;
	}
	
	/**Magazine(String name, String type, String id)
	 * Constructor which instantiates a Magazine object with given volume
	 * and given status
	 * @param name - name of Magazine
	 * @param type - type of item
	 * @param id - id of Magazine
	 * @param volume - volume of Magazine
	 */
	public Magazine(String name, String type, String id, String volume, 
			int libraryCode, 
			int uniqueQuantityID,
			String status,
			boolean checkoutable){

		super(status, checkoutable);
		libraryID = libraryCode;
		this.volume = volume;
		item_name = name;
		item_type = type;
		item_id = id;
		checkedOut = false;
		returnDate = "NONE";
		this.uniqueQuantityID = uniqueQuantityID;
	}
	
	/**Magazine(String name, String type, String id)
	 * Constructor which loads a saved Magazine object
	 * @param name - name of Magazine
	 * @param type - type of item
	 * @param id - id of Magazine
	 * @param volume - volume of Magazine
	 */
	public Magazine(String name, 
					String type, 
					String id, 
					String volume, 
					int libraryCode, 
					int uniqueQuantityID,
					String returnDate, 
	    			boolean checkedOut,
	    			boolean isLate,
	    			double fee,
	    			String checkedOutBy,
	    			String status,
	    			boolean checkoutable){

		super(returnDate, checkedOut, isLate, fee, checkedOutBy, status, checkoutable);
		libraryID = libraryCode;
		this.volume = volume;
		this.item_name = name;
		this.item_type = type;
		this.item_id = id;
		this.uniqueQuantityID = uniqueQuantityID;
	}
	
	/**Magazine(String name, String type, String id)
	 * Constructor which loads a saved Magazine object
	 * called by XMLParser
	 * @param name - name of Magazine
	 * @param type - type of item
	 * @param id - id of Magazine
	 * @param volume - volume of Magazine
	 */
	public Magazine(String type, String id, String name, 
			String volume, int libraryCode, 
			boolean fromXML, int uniqueQuantityID){
		libraryID = libraryCode;
		this.volume = volume;
		item_name = name;
		item_type = type;
		item_id = id;
		checkedOut = false;
		returnDate = "NONE";
		this.uniqueQuantityID = uniqueQuantityID;
		this.status = "AVAILABLE";
		this.checkoutable = true;
	}

	/**getVolume()
	 * Simple getter
	 * @return - volume number
	 */
	public String getVolume() {
		return volume;
	}
	
	/**setVolume()
	 * Simple setter
	 * @param volume - volume nuber
	 */
	public void setVolume(String volume) {
		this.volume = volume;
	}

	/**checkOut()
	 * This method sets the checkedOut field to true, resets the returnDate, and sets the returnDate as needed.
	 */
	public void checkOut(){
		if(checkedOut == false && checkoutable){
			//If you're going to check it out, calculate the current day
			returnDate = LocalDate.now().toString();
			checkedOut = true;
			status = "CHECKED OUT";
			checkoutable = false;
			
			//Added x days to the current day, to get the return date
			returnDate = LocalDate.parse(returnDate).plusDays(7).toString();
		}
	}
	
	/**toString()
	 * Typical overriden toString() method. Edited to fit with Text Based UI needs.
	 */
	public String toString(){
		String line = String.format("ID: %s | TITLE: %s | TYPE: %s | STATUS: %s | VOLUME: %s | LIBRARY ID: %d | Unique ID: %d", 
				item_id, item_name, item_type, status(), volume, libraryID, uniqueQuantityID);
		return line;
	}
}
