package com.implementation.hoonigan;


import com.gui.hoonigan.*;
import java.io.BufferedReader;
import java.io.IOException;

import com.google.gson.*;

/**Parser class
 * 
 * This class reads a JSON file, and parses it with GSON. 
 * The parsed output is written to a HashMap containing <userName, Client>.
 * @author Hoonigan
 * 
 */

public class JsonClientParser {
	/**Invariant Comments
	 * - gson is a JSON Parser, it is instantiated and initialized only once. 
	 *   Its value never changes after initial initialization.
	 * - br is a streaming text reader, which reads some character input stream. 
	 *   It reads a JSON file in this class, and its value never changes beyond the initial reading.
	 * - gsonClientsArray is an instance of a class that contains parsing rules on how to parse into 
	 *   an HashMap that will hold LibraryClients. Once parsing is completed, this variable is never 
	 *   changed or used again.
	 */
	
	private Gson gson;
	private BufferedReader br;
	private GsonClientList gsonClientArray;
	
	/**Parser(BufferedReader br)
	 * This is a constructor which initializes a GSON Parser, reads JSON file location, 
	 * and parses the Client found in the JSON file into a HashMap.
	 * @param br is the location of the passed in JSON FILE
	 */
	public JsonClientParser(BufferedReader br){
		this.gson = new Gson();
		this.br = br;
		this.gsonClientArray = gson.fromJson(br, GsonClientList.class);
	}
	
	/** parse()
	 * 	This method parses a json file, into a HashMap of Client(s)
	 */
	public int parse(){
		int ans = 0;
		try{
			/** If the ArrayList from GsonClientList is not empty, for all elements in array, 
			*   put all elements to HashMap
			*/
			if(gsonClientArray != null){
				for (GsonClient client : gsonClientArray.getAllGsonClients()){
					/** Turn the GsonClient -> Client, and put them in the global map, 
					*   as well as the library specific map
					*/
					if(client.getAccess()){
						//Add to global map of clients
						addClientToMultiMap(true, client);
					}
					else {
						addClientToMultiMap(false, client);
					}
				}
			}else{//Your JSON file is empty
				return -1;
			}
		}catch(JsonParseException  e){
			e.printStackTrace();
		}
		
		finally{
			if (br != null) {
				try{
					br.close();
				}
				catch (IOException e) {
					e.printStackTrace();
				}
			}	
		}
		return ans;
	}
	
	/**addClientToMultiMap(GsonClient client)
	 * This method converts a GsonClient into an Client, 
	 * @param client - a GsonClient [defined as one client block from the json file] that is being passed in 
	 *   straight from I/O
	 * @param clientType - the Client Type <BookClient, CD, DVD, Magazine> of the GsonClient being passed in
	 */
	public void addClientToMultiMap(boolean isAdmin, GsonClient client){
		Client thisClient;
		
		//If this username is already in our database
		if(SingletonInformationExpert.getClientList().containsKey(client.getUserName())){
			//ignore this client
		}else{
			//Add this ID to the MultiMap
			//Add this ID to the MultiMap based on Type
			if(isAdmin){
				//String firstName, String lastName, String userName, char[] password, 
				//String streetAddress, String securityQuestion, String securityAnswer
				thisClient = new Admin(client.getFirstName(), 
						client.getLastName(), 
						client.getUserName(),
						client.getPassword(),
						client.getStreetAddress(),
						client.getSecurityQuestion(),
						client.getSecurityAnswer());
				SingletonInformationExpert.addToClientHashMap(thisClient);
			}
			else {
				thisClient = new Member(client.getFirstName(), 
						client.getLastName(), 
						client.getUserName(),
						client.getPassword(),
						client.getStreetAddress(),
						client.getSecurityQuestion(),
						client.getSecurityAnswer());
				SingletonInformationExpert.addToClientHashMap(thisClient);
			}
		}
	}
}