package com.implementation.hoonigan;

import com.gui.hoonigan.*;
import com.google.common.collect.Multimap;


public class CheckoutReconciler {

	public static void reconcileCatalog() {

    	// Map for all LibraryItems in system [ID, Item]
    	Multimap<String, Item> libraryItemList = SingletonInformationExpert.getLibraryItemList();
    		
        //For all the Items from the passed-in Multimap
		for (Item item : libraryItemList.values()){
			if (item.isCheckedOut()) {
				String username = item.getCheckedOutBy();
				Client checkerOuter = SingletonInformationExpert.getClientAccount(username);
				checkerOuter.addToCheckedOutList(item);
			}
		}
		
    }

}
