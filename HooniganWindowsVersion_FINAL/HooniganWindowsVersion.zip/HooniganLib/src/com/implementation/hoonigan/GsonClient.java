package com.implementation.hoonigan;

import java.util.ArrayList;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**GsonClient class
 * 
 * This class defines the GSON Parsing Rules, which will determine how the GSON Parser parses the JSON file
 * @author Hoonigan
 * 
 */
public class GsonClient {
	/**Invariant Comments
	 * - firstName is a String that will be parsed based on the Parser recognizing the SerializedName "firstName".
	 * - lastName is a String that will be parsed based on the Parser recognizing the SerializedName "lastName".
	 * - userName is a String that will be parsed based on the Parser recognizing the SerializedName "userName".
	 * - password is a char[] that will be parsed based on the Parser recognizing the SerializedName "password".
	 * - streetAddress is a String that will be parsed based on the Parser recognizing the SerializedName "streetAddress".
	 * - securityQuestion is a String that will be parsed based on the Parser recognizing the SerializedName "securityQuestion".
	 * - securityAnswer is a String that will be parsed based on the Parser recognizing the SerializedName "securityAnswer".
	 * - access is a boolean that will be parsed based on the Parser recognizing the SerializedName "access".
	 * - itemsCheckedOut is a List<GsonItem> that will be parsed based on the Parser recognizing the SerializedName "itemsCheckedOut".
	 */ 
	@SerializedName("firstName")
	@Expose
	private String firstName;
	
	@SerializedName("lastName")
	@Expose
	private String lastName;
	
	@SerializedName("userName")
	@Expose
	private String userName;
	
	@SerializedName("password")
	@Expose
	private char[] password;
	
	@SerializedName("streetAddress")
	@Expose
	private String streetAddress;

	@SerializedName("securityQuestion")
	@Expose
	private String securityQuestion;
	
	@SerializedName("securityAnswer")
	@Expose
	private String securityAnswer;
	
	@SerializedName("access")
	@Expose
	private boolean access;
	
	@SerializedName("itemsCheckedOut")
	@Expose
	private ArrayList<GsonItem> itemsCheckedOut;

	public String getFirstName() {
		return firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public String getUserName() {
		return userName;
	}

	public char[] getPassword() {
		return password;
	}

	public String getStreetAddress() {
		return streetAddress;
	}

	public String getSecurityQuestion() {
		return securityQuestion;
	}

	public String getSecurityAnswer() {
		return securityAnswer;
	}

	public boolean getAccess() {
		return access;
	}

	public ArrayList<GsonItem> getItemsCheckedOut() {
		return itemsCheckedOut;
	}
	
}