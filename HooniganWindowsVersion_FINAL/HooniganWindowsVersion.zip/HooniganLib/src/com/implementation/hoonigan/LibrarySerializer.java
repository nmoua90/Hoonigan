package com.implementation.hoonigan;

import com.gui.hoonigan.*;

import java.lang.reflect.Type;

import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;
import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintStream;

import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Multimap;
import java.util.ArrayList;
import java.util.Map;
import java.util.Date;
import java.text.SimpleDateFormat;

/**LibrarySerializer
 * This class serializes Clients, Items, and Libraries.
 * @author Hoonigan
 *
 */
public class LibrarySerializer {
	//This instantiates all relevant lists for metadata
	
	// Map with all Libraries
	private Multimap<Integer, Library> multiLibraryList = ArrayListMultimap.create();
		
	/**
	 * Default
	 */
	public LibrarySerializer(){}

	/**
	 * This class defines different types of Objects to serialize
	 * @author Hoonigan
	 *
	 */
    public static class ItemSerializer implements JsonSerializer<Object> {
    	public ItemSerializer(){}
    	
        public JsonElement serialize(final Object saveThis, 
        		final Type type, final JsonSerializationContext context) {
        	
        	//Create a new Json object
            JsonObject result = new JsonObject();
            
            //Return a Json object
            return result;
        }
        
    }
    
	// Write all elements of a list into a JSON string
	private static String buildJsonString(String title, ArrayList<String> items) {

		StringBuilder sb = new StringBuilder("{\n  \"" + title + "\":\n  [\n");
		
		//For everything in your ArrayList
		for (int i = 0; i < items.size() - 1; i++){
			sb.append("    \n");
			
			//Get the i'th element
			String string = "      " + items.get(i);
			sb.append(string);
			
			sb.append(",\n");
			
		}
		
		//Your String builder is complete, close the syntax of the JSON array
		sb.append(items.get(items.size() - 1) + "\n    ]\n}");
		String result = sb.toString();
		return (result);
	}
	
	/**
	 * Save String representing serialized JSON objects with timestamp
	 */
	private static void saveJson(String filetype, String jsonitems) {
		String timeStamp = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
		
		String filename = timeStamp + "_" + filetype + ".json";
		//Attempt to serialize to JSON
		try {
			//Name your save file
			File file = new File(filename);
			
			//If the file does not exist, create it
			if (!file.exists()){
				file.createNewFile();
			}
			
			//Get a Printstream ready to write to your previously declared file 
			PrintStream out = new PrintStream(new FileOutputStream(file));
			
			//Print all elements you put in the Stringbuilder, close when done
			out.print(jsonitems);
			out.close();			
		} catch (Exception ex) {
			System.out.println("Error writing file");
		}
	}

	/**
     * Saves Library Catalog and Client Database as JSON files
     */
    public void SerializeLibraryCatalog() {
    	
    	serializeCatalog();
    	serializeClientDatabase();
    	
    }
	
	/**
     * Saves Library Catalog as JSON file
     */
    public void serializeCatalog() {

    	// Map for all LibraryItems in system [ID, Item]
    	Multimap<String, Item> libraryItemList = SingletonInformationExpert.getLibraryItemList();
    		
    	//Create an array that holds Strings
        ArrayList<String> items = new ArrayList<String>();
        
        //Create a GSON Builder, which will use info from Item
        com.google.gson.Gson gson = new GsonBuilder().registerTypeAdapter(Item.class, new ItemSerializer()).create();
        
        //For all the Items from the passed in Multi-Map
		for (Item item : libraryItemList.values()){
			//Set a string to equal the JSON object of an Item
			String jo = gson.toJson(item);
			//Add this String to your ArrayList
			items.add(jo);
		}
		
		String jsonitems = buildJsonString("library_items", items);
		
		saveJson("STATE", jsonitems);
		
    }
    
    /**
     * Saves Client Database as JSON file
     */
    public void serializeClientDatabase() {

    	// Map with all User accounts [userName, password]
    	Multimap<String, Client> multiClientList = ArrayListMultimap.create();
    	Map<String, Client> clientList = SingletonInformationExpert.getClientList();
    			
    	for (String key : clientList.keySet()){
    		multiClientList.put(key, clientList.get(key));
    	}
    	
    	//Create an array that holds Strings
        ArrayList<String> clients = new ArrayList<String>();
        
        //Create a GSON Builder, which will use info from Item
        com.google.gson.Gson gson = new GsonBuilder().registerTypeAdapter(Client.class, new ItemSerializer()).create();
        
        //For all the Items from the passed in Multi-Map
		for (Client client : multiClientList.values()){
			//Set a string to equal the JSON object of an Item
			String user = gson.toJson(client);
			//Add this String to your ArrayList
			clients.add(user);
		}
		
		String jsonclients = buildJsonString("clients", clients);
		
		saveJson("CLIENTS", jsonclients);
		
    }
    
    /**convertIntoLibraryMultiMap(Map<Integer, Library> map)
     * Converts Library Map into MultiMap
     */
    public void convertIntoLibraryMultiMap(Map<Integer, Library> map){
    	for (int key : map.keySet()){
    		multiLibraryList.put(key, map.get(key));
    	}
    }
        
}