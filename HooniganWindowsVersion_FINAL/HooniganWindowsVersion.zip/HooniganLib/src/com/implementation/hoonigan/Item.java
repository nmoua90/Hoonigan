package com.implementation.hoonigan;

/**Item abstract class
 * 
 * An abstract class, which extends into five Subclasses: Magazine, Book, CD, DVD, UndefinedItem
 * @author Hoonigan
 *
 */

abstract public class Item{
	protected String item_name;
	protected String item_type;
	protected String item_id;
	protected String returnDate;
	protected boolean checkedOut;
	protected int libraryID;
	protected boolean isLate;
	protected double fee;
	protected int uniqueQuantityID;
	protected String checkedOutBy;
	protected String status;
	protected boolean checkoutable;
	
    /**Item()
     * Default constructor.
     */
    public Item(){
    }
    
    /**Item()
     * Constructor to use when loaded previous state of library
     */
    public Item(String returnDate, 
    			boolean checkedOut,
    			boolean isLate,
    			double fee,
    			String checkedOutBy,
    			String status,
    			boolean checkoutable){
    	
    	this.returnDate = returnDate;
    	this.checkedOut = checkedOut;
    	this.isLate = isLate;
    	this.fee = fee;
    	this.checkedOutBy = checkedOutBy;
    	this.status = status;
    	this.checkoutable = checkoutable;
    	
    }
    
    /**Item()
     * Constructor to use when adding new items manually
     */
    public Item(String status,
    			boolean checkoutable){
    	
    	this.status = status;
    	this.checkoutable = checkoutable;
    	
    }
    
    /**getLibraryID();
     * Typical getter
     * @return the ID of the Library this item is from
     */
    public int getLibraryID() {
		return libraryID;
	}


    /**setLibraryID(int LibraryID)
     * Typical setter
     * @param libraryID: The ID of the Library this item is from
     */
	public void setLibraryID(int libraryID) {
		this.libraryID = libraryID;
	}

	/**getItem_name()
	 * Typical getter
	 */
	public String getItem_name() {
		return item_name;
	}

	/**setItem_name()
	 * Typical setter
	 */
	public void setItem_name(String item_name) {
		this.item_name = item_name;
	}

	/**getItem_type()
	 * Typical getter
	 */
	public String getItem_type() {
		return item_type;
	}

	/**setItem_type()
	 * Typical setter
	 */
	public void setItem_type(String item_type) {
		this.item_type = item_type;
	}

	/**getItem_id()
	 * Typical getter
	 */
	public String getItem_id() {
		return item_id;
	}

	/**setItem_id()
	 * Typical setter
	 */
	public void setItem_id(String item_id) {
		this.item_id = item_id;
	}

 	/**isCheckedOut()
 	 * This method returns a boolean value based on whether an item is checked out
 	 * @return a boolean based on whether an item is checked out
 	 */
 	public boolean isCheckedOut(){
 		return checkedOut;
 	}
 	
	/**checkIn()
	 * This method sets the checkedOut field to false.
	 */
	public void checkIn(){
		if(checkedOut == true){
			checkedOut = false;
			returnDate = new String("NONE");
			checkedOutBy = null;
			status = "AVAILABLE";
			checkoutable = true;
		}
	}
	
	/**returnDate()
	 * This method returns a checkout date that corresponds to 21 days past the current day.
	 * @return a String which represents a date
	 */
	public String returnDate(){
		return returnDate.toString();
	}
	
	/**status()
	 * This method returns a String based on the availability of an item
	 * @return a string based on the availability of an item
	 */
	public String status() {
		if(this.isCheckedOut()) {
			return "DUE " + this.returnDate;
		}
		else {
			return this.status;
		}
	}
 	
	/**equals(Object obj)
	 * Compares one item with another, based on Item IDs.
	 */
	@Override
	public boolean equals(Object obj){
		if (obj == null) {
	        return false;
	    }
		
		Item paramItem = (Item) obj;
		
		if(paramItem.item_id.compareToIgnoreCase(item_id) == 0){
			return true;
		}
		
		return false;
	}
    /**checkOut()
     * Method returns a checkOut date for an item. Abstract implementation must be changed for each specific object/item.
     */
    public abstract void checkOut();
    
    /**isSisterLibraryItem()
     * This method returns a boolean value based on whether an item belongs to the sister library or not.
     * If libraryID == 0, the item is local. If libraryID != 0, the item came from another library.
     * @return a boolean based on whether an item belongs to the sister library or not.
     */
    public boolean isSisterLibraryItem(){
        if(libraryID != 0){
        	return true;
        }
        return false;
    }
    
    /**
     * 
     * @return
     */
    public boolean isLate() {
		return isLate;
	}

    /**
     * 
     * @param isLate
     */
	public void setLate(boolean isLate) {
		this.isLate = isLate;
	}

	/**
	 * 
	 * @return
	 */
	public double getFee() {
		return fee;
	}

	/**
	 * 
	 * @param fee
	 */
	public void setFee(double fee) {
		this.fee = fee;
	}

	/**
	 * 
	 * @return
	 */
	public int getUniqueQuantityID() {
		return uniqueQuantityID;
	}

	/**
	 * 
	 * @param uniqueQuantityID
	 */
	public void setUniqueQuantityID(int uniqueQuantityID) {
		this.uniqueQuantityID = uniqueQuantityID;
	}

	
	/**
	 * 
	 * @return
	 */
	public String getCheckedOutBy() {
		return checkedOutBy;
	}

	/**
	 * 
	 * @param checkedOutBy
	 */
	public void setCheckedOutBy(String checkedOutBy) {
		this.checkedOutBy = checkedOutBy;
	}

	public String getReturnDate() {
		return returnDate;
	}

	public void setReturnDate(String returnDate) {
		this.returnDate = returnDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public boolean isCheckoutable() {
		return checkoutable;
	}

	public void setCheckoutable(boolean checkoutable) {
		this.checkoutable = checkoutable;
	}

	public void setCheckedOut(boolean checkedOut) {
		this.checkedOut = checkedOut;
	}

	/**toString()
     * Method returns information about Item as String.
     */
    @Override
    public abstract String toString();
}
