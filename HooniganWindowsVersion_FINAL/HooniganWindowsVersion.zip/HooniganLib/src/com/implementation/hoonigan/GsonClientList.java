package com.implementation.hoonigan;

import java.util.ArrayList;
import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**GsonClientList class
 * 
 * This class takes the Gson Clients found in a JSON file, and parses the elements 
 * into an ArrayList, based on the parsing rules found in the 
 * GsonClient class.
 * @author Hoonigan
 * 
 */
public class GsonClientList {
	/**Invariant comments
	 * - clients is an ArrayList that parses based on the SerializedName 
	 *   'clients'. If parsed, clients are stored in an 
	 *   ArrayList. Once fully parsed, the number 
	 *   of elements in the Array never increase, and are never removed.
	 */
	@SerializedName("clients")
	@Expose
	private List<GsonClient> clients = new ArrayList<GsonClient>();

	/**getAllGsonClients()
	 * Simple getter method
	 * @return clients - An ArrayList holding Gson Clients
	 */
	public List<GsonClient> getAllGsonClients() {
		return clients;
	}

}
