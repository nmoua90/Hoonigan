package com.implementation.hoonigan;

import java.time.LocalDate;

/**Books class
 *  
 * A simple Book class--extended from Abstract Library_Items class
 * @author Hoonigan
 * 
 */
public class BookItem extends Item{
	/** Invariant Comments
	 *  - item_author is initialized in the non-default CD Constructor. It's value can be changed, though changing it is not realistically supposed to be done.
	 */ 
	private String item_author;
	
	public BookItem(){
	}
	
	/**Book(String name, String type, String id, String author)
	 * Constructor which instantiates a Book object with default status
	 * @param name - name of Book
	 * @param type - type of item
	 * @param id - id of Book
	 * @param libraryCode - the libraryID associated with this item
	 * @param author - artist of Book
	 */
	public BookItem(String name, String type, String id, String author, int libraryCode, int uniqueQuantityID){
		libraryID = libraryCode;
		item_name = name;
		item_type = type;
		item_id = id;
		item_author = author;
		checkedOut = false;
		returnDate = "NONE";
		this.uniqueQuantityID = uniqueQuantityID;
		this.status = "AVAILABLE";
		this.checkoutable = true;
	}
	
	/**Book(String name, String type, String id, String author)
	 * Constructor which instantiates a Book object with given status
	 * called from AddItemFrame
	 * @param name - name of Book
	 * @param type - type of item
	 * @param id - id of Book
	 * @param libraryCode - the libraryID associated with this item
	 * @param author - artist of Book
	 */
	public BookItem(String name, 
			String type, 
			String id, 
			String author, 
			int libraryCode, 
			int uniqueQuantityID,
			String status,
			boolean checkoutable){

		super(status, checkoutable);
		libraryID = libraryCode;
		item_name = name;
		item_type = type;
		item_id = id;
		item_author = author;
		checkedOut = false;
		returnDate = "NONE";
		this.uniqueQuantityID = uniqueQuantityID;
	}
	
	/**Book(String name, String type, String id, String author,
	 * 		int libraryCode, int uniqueQuantityID, String returnDate,
	 * 		boolean checkedOut, boolean isLate, double fee, String checkedOutBy)
	 * Constructor which loads a saved Book object
	 * @param name - name of Book
	 * @param type - type of item
	 * @param id - id of Book
	 * @param libraryCode - the libraryID associated with this item
	 * @param author - artist of Book
	 * @param libraryCode 
	 * @param uniqueQuantityID
	 * @param returnDate 
	 * @param checkedOut
	 * @param isLate
	 * @param fee
	 * @param checkedOutBy
	 */
	public BookItem(String name, 
					String type, 
					String id, 
					String author, 
					int libraryCode, 
					int uniqueQuantityID,
					String returnDate, 
	    			boolean checkedOut,
	    			boolean isLate,
	    			double fee,
	    			String checkedOutBy,
	    			String status,
	    			boolean checkoutable){

		super(returnDate, checkedOut, isLate, fee, checkedOutBy, status, checkoutable);
		this.libraryID = libraryCode;
		this.item_name = name;
		this.item_type = type;
		this.item_id = id;
		this.item_author = author;
		this.uniqueQuantityID = uniqueQuantityID;
	}
	
	/**
	 * 
	 * @param type
	 * @param id
	 * @param author
	 * @param name
	 * @param libraryCode
	 * @param fromXML
	 */
	public BookItem(String type, String id, String author, String name, int libraryCode, boolean fromXML, int uniqueQuantityID){
		libraryID = libraryCode;
		item_name = name;
		item_type = type;
		item_id = id;
		item_author = author;
		checkedOut = false;
		returnDate = "NONE";
		this.uniqueQuantityID = uniqueQuantityID;
		this.status = "AVAILABLE";
		this.checkoutable = true;
	}

	/**getItem_author()
	 * Typical getter
	 */
	public String getItem_author() {
		return item_author;
	}

	/**setItem_author()
	 * Typical setter
	 */
	public void setItem_author(String item_author) {
		this.item_author = item_author;
	}
	
	/**checkOut()
	 * This method sets the checkedOut field to true, resets the returnDate, and sets the returnDate as needed.
	 */
	public void checkOut(){
		if(checkedOut == false && checkoutable){
			//If you're going to check it out, calculate the current day
			returnDate = LocalDate.now().toString();
			checkedOut = true;
			status = "CHECKED OUT";
			checkoutable = false;
			
			//Added x days to the current day, to get the return date
			returnDate = LocalDate.parse(returnDate).plusDays(21).toString();
		}
	}
	
	/**toString()
	 * Typical overriden toString() method. Edited to fit with Text Based UI needs.
	 */
	public String toString(){
		String line = String.format("ID: %s | TITLE: %s | TYPE: %s | AUTHOR: %s | STATUS: %s | LIBRARY ID: %d | Unique ID: %d", 
				item_id, item_name, item_type, item_author, status(), libraryID, uniqueQuantityID);
		return line;
	}
}
