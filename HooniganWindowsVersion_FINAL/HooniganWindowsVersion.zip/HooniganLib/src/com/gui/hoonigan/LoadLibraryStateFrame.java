package com.gui.hoonigan;

import com.google.gson.JsonSyntaxException;
import com.implementation.hoonigan.*;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.filechooser.FileFilter;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JFileChooser;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

/**LoadLibraryStateFrame
 * This class creates the frame, where an ADMIN can load Library state files [in JSON format].
 * @author Hoonigan
 *
 */
public class LoadLibraryStateFrame {
	private JFrame frame = new JFrame("Load Previous Library State");
	private SingletonInformationExpert globalVariables = SingletonInformationExpert.getInstance();
	private JPanel contentPane;
	private final int LIBRARYID = 0;
	private int itemErrorStatus;
	private int clientErrorStatus;

	/**LoadLibraryStateFrame()
	 * Constructor. Creates the frame.
	 */
	public LoadLibraryStateFrame() {
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.setBounds(100, 100, 496, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		frame.setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel infoMessage1 = new JLabel("Choose a STATE file, that you wish to reload.");
		infoMessage1.setFont(new Font("Tw Cen MT", Font.PLAIN, 15));
		infoMessage1.setBounds(97, 102, 290, 34);
		frame.setLocationRelativeTo(infoMessage1);
		contentPane.add(infoMessage1);
		
		JButton loadPrevStateButton = new JButton("Load Previous State");
		loadPrevStateButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				try{
					initFileChooser(LIBRARYID);
					closeFrame();
				}catch(NumberFormatException e){
					JOptionPane.showMessageDialog(null, "Your Library ID is invalid", "Error!", 
							JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		loadPrevStateButton.setFont(new Font("Tw Cen MT", Font.PLAIN, 15));
		loadPrevStateButton.setBounds(141, 158, 187, 48);
		contentPane.add(loadPrevStateButton);	
		
		JLabel infoMessage2 = new JLabel("A State File contains the metadata of the previous State of the Library.");
		infoMessage2.setFont(new Font("Tw Cen MT", Font.PLAIN, 15));
		infoMessage2.setBounds(34, 37, 436, 14);
		contentPane.add(infoMessage2);
	}
	

	/**initFileChooser()
	 * Initialize a FileChooser to select a Library Items file
	 */
	public void initFileChooser(int LIBRARYID){
		String filePrefix;
		JFileChooser chooser = new JFileChooser();
		File workingDirectory = new File(System.getProperty("user.dir"));
		
		chooser.setCurrentDirectory(workingDirectory);
		chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
		chooser.setAcceptAllFileFilterUsed(false);
		chooser.addChoosableFileFilter(new FileFilter()
		{
				//In the FileChooser window, specifically show files that end with 'ITEMS.json'
				@Override
				public boolean accept(File f) {
					return f.isDirectory() || f.getName().endsWith("STATE.json");
				}

				@Override
				public String getDescription() {
					return "STATE Files";
				}
		});
		
		switch (chooser.showOpenDialog(null)){
			case JFileChooser.APPROVE_OPTION:
				try(BufferedReader br = new BufferedReader(new FileReader(chooser.getSelectedFile()))) {
					globalVariables.getLibraryItemList().clear();
					callJsonParser(br, LIBRARYID);
					filePrefix = chooser.getSelectedFile().getName().substring(0, 15);
					BufferedReader brc = new BufferedReader(new FileReader(new File(filePrefix + "CLIENTS.json")));
					callJsonClientParser(brc);
					CheckoutReconciler.reconcileCatalog();
					
				}catch(IOException | NumberFormatException | ArrayIndexOutOfBoundsException | 
						JsonSyntaxException e) {
					if(e.getClass().getName().equalsIgnoreCase("java.io.FileNotFoundException")){
						JOptionPane.showMessageDialog(null, "Failed to find a Client State file to load.", "Error", JOptionPane.ERROR_MESSAGE);
					}
					else if(e.getClass().getName().equalsIgnoreCase("com.google.gson.JsonSyntaxException")){
						JOptionPane.showMessageDialog(null, "Failed to load because JSON file is misformatted.", "Error", JOptionPane.ERROR_MESSAGE);
					}
					else{
						JOptionPane.showMessageDialog(null, "Failed to read file", "Error", JOptionPane.ERROR_MESSAGE);
					}
				}
		}
		
	}//end of initFileChooser
	
	/**callJsonParser(BufferedReader br, int libraryID)
	 * Calls the JSON Parser and parses a JSON file. Updates Global variable HashMap containing Library Items with recently parsed items.
	 * @param br - Buffered reader passed in from JFileChooser
	 * @param libraryID - the libraryID the batch of JSON files are coming from
	 */
	private int callJsonParser(BufferedReader br, int libraryID) {
		//Create JSON parser class
		JsonParser jParser = new JsonParser(br, libraryID);
		
		//Parse Json file
		itemErrorStatus = jParser.parse(true);
		
		return itemErrorStatus;
		//Display whether Loading of Items was a success
		//displayErrorLoadingMessage(errorStatus);
	}

	/**callJsonClientParser(BufferedReader brc)
	 * Calls the JSON Parser and parses a JSON file. 
	 * Updates Global variable HashMap containing Library Clients with recently parsed clients.
	 * @param brc - Buffered reader passed in from JFileChooser
	 */
	private void callJsonClientParser(BufferedReader brc) {
		//Create JSON parser class
		JsonClientParser jCParser = new JsonClientParser(brc);
		
		//Parse Json file
		clientErrorStatus = jCParser.parse();
				
		//Display whether Loading of clients was a success
		displayErrorLoadingMessage();
	}
	
	/**displayErrorLoadingMessage()
	 * Displays a pop-up, either telling the user of a successive file load, or a failure of file load.
	 * @param error - the code responding to successful load. 0 for successive load, -1 for failed load.
	 */
	public void displayErrorLoadingMessage(){
		if(itemErrorStatus == 0 && clientErrorStatus == 0){
			JOptionPane.showMessageDialog(null, "The state of the library was loaded!", "Success!", JOptionPane.PLAIN_MESSAGE);
		}else if(itemErrorStatus == -1 || clientErrorStatus == -1){
			JOptionPane.showMessageDialog(null, "One of the files did not read properly. Check if file format is valid", 
					"Failure!", JOptionPane.WARNING_MESSAGE);
		}else{
			JOptionPane.showMessageDialog(null, "Some items in the file were read, but others are misformatted.", 
					"Failure!", JOptionPane.WARNING_MESSAGE);
		}
	}

	/**closeFrame()
	 * Close the frame.
	 */
	public void closeFrame(){
		frame.setVisible(false);
		frame.dispose();
	}
	
	/**setvisible()
	 * Make the frame visible.
	 */
	public void setVisible(){
		frame.setVisible(true);
	}
}
