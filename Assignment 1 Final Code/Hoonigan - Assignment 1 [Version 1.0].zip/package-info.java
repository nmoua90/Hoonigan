/**Hoonigan
 * 
 * This is a simple package, which contains all relevant classes for the Hoonigan Library Program.
 * @author Hoonigan
 *
 */
package hoonigan;